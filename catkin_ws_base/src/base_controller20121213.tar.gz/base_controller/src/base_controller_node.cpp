#include "ros/ros.h"  //ros需要的头文件
#include "base_controller/base_controller.h"


int main(int argc, char **argv)
{
    ros::init(argc, argv, "base_controller");
    ros::NodeHandle n;  //定义节点进程句柄
    ros::Rate loop_rate(20);//设置周期休眠时间

    Base_Controller base_controller(n);

    while(ros::ok())
    {
        base_controller.control_core();
        ros::spinOnce();//周期执行
        loop_rate.sleep();//周期休眠
    }

    return 0;
}
