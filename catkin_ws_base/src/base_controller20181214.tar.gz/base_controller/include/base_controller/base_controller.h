﻿#ifndef BASE_CONTROLLER_H
#define BASE_CONTROLLER_H

/******************************************************************
基于串口通信的ROS小车基础控制器，功能如下：
1.实现ros控制数据通过固定的格式和串口通信，从而达到控制小车的移动
2.订阅了/cmd_vel主题，只要向该主题发布消息，就能实现对控制小车的移动
3.发布里程计主题/odm

串口通信说明：
1.写入串口
（1）内容：左右轮速度，单位为mm/s
（2）格式：１０字节,[右轮速度４字节][左轮速度４字节][结束符"\r\n"２字节]
2.读取串口
（1）内容：小车x,y坐标，方向角，线速度，角速度，单位依次为：mm,mm,rad,mm/s,rad/s
（2）格式：２１字节，[Ｘ坐标４字节][Ｙ坐标４字节][方向角４字节][线速度４字节][角速度４字节][结束符"\n"１字节]
*******************************************************************/
#include "ros/ros.h"  //ros需要的头文件
#include <geometry_msgs/Twist.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
//以下为串口通讯需要的头文件
#include <string>
#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <math.h>

#include <serial/serial.h>  //ROS已经内置了的串口包
#include <std_msgs/String.h>
#include <std_msgs/Empty.h>
#include <id_data_msgs/ID_Data.h>
#include "sensor_msgs/LaserScan.h"

using namespace std;

union floatTochar //union的作用为实现char数组和float之间的转换
{
    float float_type;
    unsigned char char_type[4];
};





//class PID{
//public:
//    PID(float kp, float ki, float kd, float lim, float integrator_lim);
//    ~PID();
//    void set_reference(float r);
//    float get_u(float y);

//private:
//    float f_kp;
//    float f_ki;
//    float f_kd;
//    float f_lim;
//    float f_integrator_lim;
//    float f_integrator;
//    float f_derivator;
//    float f_r;
//};



class Base_Controller
{
public:
    Base_Controller(ros::NodeHandle node);
    ~Base_Controller();
    void control_core();

private:
    // init funcs
    char serial_init(void);
    void base_init(void);
    void target_init(void);

    // notice_pub_sub
    boost::function<void (const id_data_msgs::ID_Data::ConstPtr&)> notice_pub_sub_msgCallbackFun;

    void notice_pub_sub_pulisher(id_data_msgs::ID_Data id_data);
    void notice_display(id_data_msgs::ID_Data notice_msg,bool set);
    void notice_sub_spinner(char set);



    void notice_msgCallback(const id_data_msgs::ID_Data::ConstPtr &notice_msg);



    // other funcs
    void velCallback(const geometry_msgs::Twist & cmd_input);
    void cmdCallback(const geometry_msgs::Twist & cmd_input);
    void scanCallback(sensor_msgs::LaserScan newscan);

    void goalCallback(const geometry_msgs::PoseStamped & Target_Pose);
    char Get_Robot_Data(void);
    void Analyze_Robot_Data(void);
    void Update_Odom_Topic_Data(void);
    void Update_Imu_Topic_Data(void);
    void get_robot_pose(void);
    void ROS_base_control_to_robot(void);
    void notice_data_clear(id_data_msgs::ID_Data *test);

    int n_robot_state; // 0: stop ; 1: controlled by keyboard; 2: controlled by Auto(target reaching or obstacle avoidance);
    bool b_Is_obstacle_avoidance;
    bool b_Is_near_goal;
    bool b_Is_scan_init;
    bool b_Is_target_init;
    float left_side_range;
    float right_side_range;
    float suitable_dist;


    // params for control u
    double robot_temp_x_buf[50];
    double robot_temp_y_buf[50];
    double robot_temp_yaw_buf[50];

    int filter_count;
    int Fliter_size;
    char robot_direction_flag;

    // params for serial com
    serial::Serial ser;
    int n_serial_ret;
    unsigned char send_data_head0,send_data_head1;  //“SI"字符
    unsigned char Send_to_Robot_data[30] = {0};   //要发给串口的数据
    string rec_buffer;  //串口数据接收变量

    unsigned char receive_data[80];                      //定义串口数据接收变量
    unsigned char receive_data_flag;
    int receive_data_flag_count;
    int n_main_count_i;

    // params for robot base
    float cf_ratio;   //转速转换比例，执行速度调整比例
    float cf_D;    //两轮间距，单位是m
    float cf_linear_temp,cf_angular_temp;//暂存的线速度和角速度

    floatTochar Target_Left_Speed,Target_Right_Speed,Target_Position_x,Target_Position_y,Target_Angle;
    floatTochar right_speed_data,left_speed_data,position_x,position_y,oriention,vel_linear,vel_angular; //odomtry
    floatTochar ACC_x,ACC_y,ACC_z,GY_x,GY_y,GY_z,QUAT_0,QUAT_1,QUAT_2,QUAT_3; // IMU

    float f_z_angle_bias_between_odom_map;
    double fine_tuning_distance;
    char fine_tuning_flag;
    char Changed_fine_tuning_flag;

    id_data_msgs::ID_Data notice_data;


    // params for target
    float covariance[36] = {0.001,   0,  0, 0,   0,     0,  // covariance on gps_x
                                       0,  0.001, 0,   0,   0,     0,  // covariance on gps_y
                                       0,  0,    1000, 0,     0,    0,  // covariance on gps_z
                                       0,  0,    0,     1000, 0,    0,  // large covariance on rot x
                                       0,  0,    0,     0,    1000, 0,  // large covariance on rot y
                                       0,  0,    0,     0,    0,     1000};  // large covariance on rot z;
    float imu_data_orientation_covariance[9] = {0.001, 0, 0, 0, 0.001, 0, 0, 0, 0.001};
    float imu_data_linear_acceleration_covariance[9] = {-1, 0, 0, 0, 0, 0, 0, 0, 0};
    float imu_data_angular_velocity_covariance[9] = {0.001, 0, 0, 0, 0.001, 0, 0, 0, 0.001};

    char target_position_index;
    bool b_Is_need_fine_tuning;

    double robot_target_x[50] =  {0.0, 0.0, 2.0, 4.54, 4.87, 5.08, 5.08, 4.93, 4.73, 4.53, 4.33, 4.33, 0.0};
    double robot_target_y[50] =  {0.0, 0.0, 0.0, 0.47, 0.47, 0.47, 0.17,-0.05,-0.05,-0.05,-0.05, 0.25, 0.0};
    double robot_target_yaw[50] ={0.0, 0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  179,  179,  179,  179,  179,  0.0};

    double robot_target_x_test[20] =  {0.0, 0.0,  4.54, 4.87, 5.08, 4.93, 4.73, 4.53, 4.33, 6.09};
    double robot_target_y_test[20] =  {0.0, 0.0,  0.47, 0.47, 0.47,-0.05,-0.05,-0.05,-0.05, 0.29};
    double robot_target_yaw_test[20] ={0.0, 0.0,  0.0,  0.0,  0.0,  179,  179,  179,  179,  90}; //





    // target pose information
    geometry_msgs::Point msg_robot_pose;  // note: remap 'z' to 'yaw'
    geometry_msgs::Point msg_target_pose;  // note: remap 'z' to 'yaw'


    // notice target
    int Arrive_target_position_flag;
    int Arrive_target_position_count;
    int Changed_target_position_flag;


    /// params for ros msg pub sub
    // tf publisher


    tf::TransformBroadcaster odom_broadcaster;//定义tf对象
    //static tf::TransformBroadcaster imu_broadcaster;//定义tf对象
    //static tf::TransformBroadcaster map_2_odom_broadcaster;//定义tf对象

    tf::TransformListener robot_pose_listener;  //创建一个监听对象
    tf::StampedTransform robot_pose_tf;


    // msg
    geometry_msgs::TransformStamped msg_odom_trans;//创建一个tf发布需要使用的TransformStamped类型消息
    geometry_msgs::TransformStamped msg_imu_trans;//创建一个tf发布需要使用的TransformStamped类型消息
    geometry_msgs::TransformStamped msg_map_2_odom_trans;//创建一个tf发布需要使用的TransformStamped类型消息
    nav_msgs::Odometry msg_odom;//定义里程计对象
    sensor_msgs::Imu msg_imu_data;
    geometry_msgs::Quaternion msg_odom_quat; //四元数变量
    geometry_msgs::Pose msg_Temp_Target_pose;

    geometry_msgs::Twist msg_target_robot_vel;
    geometry_msgs::Twist msg_plan_robot_vel;


    // sub
    ros::Subscriber sub_cmd_vel; //订阅/cmd_vel主题
    ros::Subscriber sub_cmd_ob; // sub command from obstacle avoidance node
    ros::Subscriber sub_Goal; //订阅/cmd_vel主题
    ros::Subscriber sub_notice;
    ros::Subscriber sub_scan;

    // pub
    ros::Publisher pub_odom; //定义要发布/odom主题
    ros::Publisher pub_IMU;
    ros::Publisher pub_ctarget; // publish current target to avoidance node
    ros::Publisher pub_notice;



    ros::SubscribeOptions notice_ops;
    ros::AsyncSpinner *notice_spinner;
    ros::CallbackQueue notice_callbackqueue;

    //rosnode
    ros::NodeHandle RosNode_;
};

#endif
