#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/robot/catkin_ws_base/src/base_controller/devel:$CMAKE_PREFIX_PATH"
export PATH="/home/robot/catkin_ws/devel/bin:/opt/ros/indigo/bin:/usr/lib/x86_64-linux-gnu/qt5/bin:/usr/bin:/usr/lib/x86_64-linux-gnu/qt5/bin:/usr/bin:/usr/local/cuda-8.0/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games"
export PWD="/home/robot/catkin_ws_base/src/base_controller"
export ROSLISP_PACKAGE_DIRECTORIES="/home/robot/catkin_ws_base/src/base_controller/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/robot/catkin_ws_base/src/base_controller:$ROS_PACKAGE_PATH"