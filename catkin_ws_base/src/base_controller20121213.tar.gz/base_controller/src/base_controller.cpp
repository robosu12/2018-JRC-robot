#include "base_controller/base_controller.h"



Base_Controller::Base_Controller(ros::NodeHandle node)
{
    RosNode_ = node;
    n_robot_state = 1;
    n_main_count_i=0;
    f_z_angle_bias_between_odom_map=0;

    filter_count=0;
    Fliter_size=10;
    suitable_dist = 0.6;


    robot_direction_flag=0;
    Arrive_target_position_count = 0;
    b_Is_obstacle_avoidance = false;
    b_Is_near_goal = false;
    b_Is_need_fine_tuning = false;

    serial_init();
    base_init();
    target_init();

    sub_cmd_vel = RosNode_.subscribe("cmd_vel", 1, &Base_Controller::velCallback, this); //订阅/cmd_vel主题
    sub_cmd_ob = RosNode_.subscribe("/command_velocity", 1, &Base_Controller::cmdCallback, this);//sub obstacle avoidance planner
    sub_Goal = RosNode_.subscribe("/move_base_simple/goal", 1, &Base_Controller::goalCallback, this); //订阅/cmd_vel主题
    sub_scan = RosNode_.subscribe("/scan",1,&Base_Controller::scanCallback,this);

    pub_odom = RosNode_.advertise<nav_msgs::Odometry>("odom_base", 1); //定义要发布/odom主题
    pub_IMU = RosNode_.advertise<sensor_msgs::Imu>("imu", 1);
    pub_ctarget = RosNode_.advertise<geometry_msgs::PointStamped>("/clicked_point", 1);

    notice_pub_sub_msgCallbackFun=boost::bind(&Base_Controller::notice_msgCallback,this,_1);
    notice_ops=ros::SubscribeOptions::create<id_data_msgs::ID_Data>(
                "/notice",
                1,
                notice_pub_sub_msgCallbackFun,
                ros::VoidPtr(),
                &notice_callbackqueue
                );
    sub_notice=RosNode_.subscribe(notice_ops);
    notice_spinner=new ros::AsyncSpinner(1,&notice_callbackqueue);

    pub_notice=RosNode_.advertise<id_data_msgs::ID_Data>("/notice",1);


}


Base_Controller::~Base_Controller(){}

void Base_Controller::control_core()
{
    if(n_main_count_i++%4==0)
    {
        //ROS_INFO("timestamp : %d , robot_base_data_count : %d",main_count_i,receive_data_flag_count);

        //get_robot_pose();
        //ROS_INFO("pose_temp : X: %2.3f , Y: %2.3f , yaw: %3.2f",msg_robot_pose.x,msg_robot_pose.y,msg_robot_pose.z);
        //ROS_INFO("robot_vel : X: %2.3f , Y: %2.3f , yaw: %3.2f",msg_target_robot_vel.linear.x,msg_target_robot_vel.linear.y,msg_target_robot_vel.angular.z);
        //ROS_INFO("plan_vel  : X: %2.3f , Y: %2.3f , yaw: %3.2f",msg_plan_robot_vel.linear.x,msg_plan_robot_vel.linear.y,msg_plan_robot_vel.angular.z);
        //ROS_INFO("pose_delta : X: %2.3f , Y: %2.3f , yaw: %3.2f",robot_delta_x,robot_delta_y,robot_delta_yaw);
        //ROS_INFO("vel : X: %2.3f , Y: %2.3f , yaw: %3.2f",robot_vel_x,robot_vel_y,robot_delta_theta);
        //ROS_INFO("dis : %3.3f",robot_delta_dis); // angular_temp

        //ROS_INFO("plan : linear_x: %2.3f , angular_z: %2.3f ",plan_robot_vel.linear.x,plan_robot_vel.angular.z);
    }

    Get_Robot_Data();

    receive_data_flag=1;
    if(receive_data_flag==1)
    {
        Analyze_Robot_Data();

        Update_Odom_Topic_Data();
        //map_2_odom_broadcaster.sendTransform(map_2_odom_trans); ////
        //odom_pub.publish(odom);
        //odom_broadcaster.sendTransform(odom_trans);

        Update_Imu_Topic_Data();
        //imu_broadcaster.sendTransform(imu_trans);
        //IMU_pub.publish(imu_data);

        receive_data_flag = 0;
        receive_data_flag_count++;
    }

    pub_odom.publish(msg_odom);
    odom_broadcaster.sendTransform(msg_odom_trans);
    pub_IMU.publish(msg_imu_data);

    try
    {
        robot_pose_listener.lookupTransform("/map", "/base_link",ros::Time(0), robot_pose_tf);
    }
    catch(tf::TransformException ex)
    {
        ROS_ERROR( "%s",ex.what());
        ros::Duration(0.5).sleep();
        //sleep(1);
    }

    double roll, pitch, yaw;

    robot_pose_tf.getBasis().getRPY(roll,pitch,yaw);
    msg_robot_pose.z = -yaw*180/3.1416 ; // yaw * 180/3.1415926  // remap z to yaw here
    msg_robot_pose.x = robot_pose_tf.getOrigin().x();
    msg_robot_pose.y = robot_pose_tf.getOrigin().y();

    if(b_Is_obstacle_avoidance)
    {
        float dx = msg_robot_pose.x - msg_target_pose.x;
        float dy = msg_robot_pose.y - msg_target_pose.y;
        float dist = sqrt(dx*dx+dy*dy);
        if(dist < 0.5)
        {
            b_Is_near_goal = true;
        }
        else
        {
            b_Is_near_goal = false;
        }
    }

    // if need obstacle avoidance and not near target then ...

    if(b_Is_obstacle_avoidance && b_Is_near_goal)
    {
        geometry_msgs::PointStamped ctarget;
        ctarget.header.frame_id = "/map";
        ctarget.header.stamp = ros::Time::now();
        ctarget.point.x = msg_target_pose.x;
        ctarget.point.y = msg_target_pose.y;
        ctarget.point.z = 0.0;
        pub_ctarget.publish(ctarget);
    }


    ROS_base_control_to_robot();

    if(Arrive_target_position_flag==1)
    {
        if(Changed_target_position_flag==1)
        {
            if(fabs(left_side_range-suitable_dist)>0.03 && b_Is_need_fine_tuning)
            {
                float left_move_dist = left_side_range-suitable_dist;
                if(left_move_dist > 0.2) left_move_dist = 0.2; //limit the correct dist
                msg_target_pose.x = msg_robot_pose.x;
                msg_target_pose.y = msg_robot_pose.y + left_move_dist;
                msg_target_pose.z = msg_robot_pose.z;  // remap z to yaw
                ROS_INFO("... Arrived_target_position ! \n");
                ROS_INFO("... begin to fine tuning... \n");
            }
            else
            {
                notice_data_clear(&notice_data);
                notice_data.id=2;
                notice_data.data[0]=15;
                notice_pub_sub_pulisher(notice_data);
                notice_display(notice_data,true);
                ROS_INFO("... Arrived_target_position ! \n");
                ROS_INFO("... send arrived information to notice ... \n");
            }
        }

        Arrive_target_position_flag=0;
        Changed_target_position_flag=0;
        Changed_fine_tuning_flag=0;
        Arrive_target_position_count=0;
        robot_direction_flag=0;
    }

}

char Base_Controller::serial_init(void)
{
    send_data_head0 = 0x53;
    send_data_head1 = 0x49;

//    Send_to_Robot_data = {0};   //要发给串口的数据

    receive_data_flag=0;
    receive_data_flag_count=0;

    try
    {
    //设置串口属性，并打开串口
        ser.setPort("/dev/serial_base");
        ser.setBaudrate(115200);
        serial::Timeout to = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(to);
        ser.open();
    }
    catch (serial::IOException& e)
    {
        ROS_ERROR_STREAM("Unable to open port ");
        return -1;
    }

    //检测串口是否已经打开，并给出提示信息
    if(ser.isOpen())
    {
        ROS_INFO_STREAM("Serial Port initialized successful");
        ROS_INFO_STREAM("Serial Port : /dev/serial_base , 115200");
        return 1;
    }
    else
    {
        return -1;
    }
}

void Base_Controller::base_init()
{
    cf_ratio = 1000.0f ;   //转速转换比例，执行速度调整比例
    cf_D = 0.2680859f ;    //两轮间距，单位是m
    cf_linear_temp=0;      //暂存的线速度
    cf_angular_temp=0;     //暂存的角速度
    fine_tuning_distance=0;
    fine_tuning_flag=0;
    Changed_fine_tuning_flag=0;
    Arrive_target_position_flag=0;
    Arrive_target_position_count=0;
    Changed_target_position_flag=0;
}


void Base_Controller::target_init()
{
    target_position_index=0;
    b_Is_need_fine_tuning = false;
}

void Base_Controller::notice_data_clear(id_data_msgs::ID_Data *test)
{
    test->id=0;
    for(int i=0;i<8;i++) test->data[i]=0;
}

void Base_Controller::velCallback(const geometry_msgs::Twist &cmd_input)
{


    // 0: stop ; 1: controlled by keyboard; 2: controlled by Auto(target reaching or obstacle avoidance);

     if(fabs(cmd_input.linear.x)<0.1 && fabs(cmd_input.angular.z)<0.1)
     {
         n_robot_state = 1;
     }
     

//     if(cmd_input.angular.z>0.9)
//     {
//         n_robot_state = 1;
//     }


     if(cmd_input.angular.z<-0.9)  // note : the clockwise rotation command if occupied by mode changing.
     {
	 if(n_robot_state == 1)
	 {
	    n_robot_state = 2;
	 }         
	 else
	 {
	    n_robot_state = 1;
	 }        
//         msg_plan_robot_vel.angular.z = 0.0 ;
//         msg_plan_robot_vel.linear.x = 0.0 ;
     }
   
    msg_plan_robot_vel.angular.z = cmd_input.angular.z * 180/3.1416 ;//获取/cmd_vel的角速度,rad/s ;
    msg_plan_robot_vel.linear.x = 2*cmd_input.linear.x ;//获取/cmd_vel的线速度.m/s ;
    cout<<"robot state: "<<n_robot_state<<endl;

}


void Base_Controller::cmdCallback(const geometry_msgs::Twist &cmd_input)
{
    if(n_robot_state == 2 && b_Is_obstacle_avoidance)
    {
        msg_plan_robot_vel.angular.z = cmd_input.angular.z * 180/3.1416 ;//获取/cmd_vel的角速度,rad/s
        msg_plan_robot_vel.linear.x = cmd_input.linear.x ;//获取/cmd_vel的线速度.m/s
    }
    else
    {
        msg_plan_robot_vel.angular.z = 0.0 ;//获取/cmd_vel的角速度,rad/s
        msg_plan_robot_vel.linear.x = 0.0 ;//获取/cmd_vel的线速度.m/s
    }

}


void Base_Controller::goalCallback(const geometry_msgs::PoseStamped &Target_Pose) //订阅/cmd_vel主题回调函数
{
    //将转换好的小车速度分量为左右轮速度
    Target_Left_Speed.float_type = 0 ;
    Target_Right_Speed.float_type = 0 ;
    Target_Position_x.float_type = Target_Pose.pose.position.x ;
    Target_Position_y.float_type = Target_Pose.pose.position.y ;
    Target_Angle.float_type = 0;

    //存入数据到要发布的左右轮速度消息
    //left_speed_data.float_type *=ratio;   //放大１０００倍，mm/s
    //right_speed_data.float_type *=ratio;  //放大１０００倍，mm/s

    for(int i=0;i<4;i++)    //将左右轮速度存入数组中发送给串口
    {
        Send_to_Robot_data[i+2] = Target_Left_Speed.char_type[i];
        Send_to_Robot_data[i+6] = Target_Right_Speed.char_type[i];
        Send_to_Robot_data[i+10] = Target_Position_x.char_type[i];
        Send_to_Robot_data[i+14] = Target_Position_y.char_type[i];
        Send_to_Robot_data[i+18] = Target_Angle.char_type[i];
    }

    //在写入串口的左右轮速度数据后加入 data head
    Send_to_Robot_data[0]=0x53;
    Send_to_Robot_data[1]=0x4a;
    Send_to_Robot_data[22]=0x41;

    //写入数据到串口
    printf("Writing position data to robot serial port : " );
    for(char i=0;i<23;i++)
    {
        printf("%x " ,Send_to_Robot_data[i]);
    }
    printf("\n" );
    ser.write(Send_to_Robot_data,23);   //发送串口数据
}

void Base_Controller::scanCallback(sensor_msgs::LaserScan newscan)
{
    if(b_Is_scan_init == false)
    {
        b_Is_scan_init = true;
        cout<<"scan is initialed!!!"<<endl;
    }

    int right_index = int((-M_PI/2.0 - newscan.angle_min)/newscan.angle_increment);
    if(right_index < 0) right_index = 0;

    int left_index = int((M_PI/2.0 - newscan.angle_max)/newscan.angle_increment);

    right_side_range = newscan.ranges[right_index];
    left_side_range = newscan.ranges[left_index];
}

char Base_Controller::Get_Robot_Data(void)
{
    std_msgs::String result;
    unsigned char temp_rece_data[50],head0=0,head1=0;
    int data_lenth=ser.available();

    if(data_lenth>61)
    {
        //ROS_INFO_STREAM("Read data from serial port" );
        //printf("byte : %d \n",data_lenth);

        while (data_lenth>0)
        {
            ser.read(&head0,1); //获取串口发送来的数据
            if(head0==0x53) break;
            data_lenth--;
            if(data_lenth<1)
            {
                ROS_WARN_STREAM("receive wrroy data : head0 ! \n");
                return 0;
            }
        }

        while (data_lenth>0)
        {
            ser.read(&head1,1); //获取串口发送来的数据
            if(head1==0x49) break;
            data_lenth--;

            if(data_lenth<1)
            {
                ROS_WARN_STREAM("receive wrroy data : head1 ! \n");
                return 0;
            }
        }

        receive_data[60] =0;
        n_serial_ret = ser.read(receive_data,61); //获取串口发送来的数据

        if(n_serial_ret==61 && receive_data[60]==0x41)
        {
            n_serial_ret=0;
            //ROS_INFO_STREAM("receive correct data from serial \n");
            receive_data_flag = 1;
        }
        else
        {
            ROS_WARN_STREAM("receive wrroy data : wrroy lenth ! \n");
        }

    } // end if(ser.available())
}

void Base_Controller::Analyze_Robot_Data(void)
{
    static char count=0;
    if(receive_data_flag==1)
    {
        for(char i=0;i<4;i++)//提取X，Y坐标，方向，线速度，角速度
        {
            position_x.char_type[i]=receive_data[i];
            position_y.char_type[i]=receive_data[i+4];
            oriention.char_type[i]=receive_data[i+8];
            vel_linear.char_type[i]=receive_data[i+12];
            vel_angular.char_type[i]=receive_data[i+16];

            ACC_x.char_type[i] = receive_data[i+20];
            ACC_y.char_type[i] = receive_data[i+24];
            ACC_z.char_type[i] = receive_data[i+28];
            GY_x.char_type[i] = receive_data[i+32];
            GY_y.char_type[i] = receive_data[i+36];
            GY_z.char_type[i] = receive_data[i+40];
            QUAT_0.char_type[i] = receive_data[i+44];
            QUAT_1.char_type[i] = receive_data[i+48];
            QUAT_2.char_type[i] = receive_data[i+52];
            QUAT_3.char_type[i] = receive_data[i+56];
        }
        //receive_data_flag = 0;

        count++;
        if(count<10)
        {
            f_z_angle_bias_between_odom_map = oriention.float_type;
        }
        else
        {
            count=11;
        }
    }
}

void Base_Controller::Update_Odom_Topic_Data(void)
{
    //将X，Y坐标，线速度缩小1000倍
    position_x.float_type/=1000; // m
    position_y.float_type/=1000; // m
    vel_linear.float_type/=1000; // m/s
    //里程计的偏航角需要转换成四元数才能发布
    msg_odom_quat = tf::createQuaternionMsgFromYaw(oriention.float_type);//将偏航角转换成四元数
    //载入坐标（tf）变换时间戳
    msg_odom_trans.header.stamp = ros::Time::now();
    //发布坐标变换的父子坐标系
    msg_odom_trans.header.frame_id = "odom_base";
    msg_odom_trans.child_frame_id = "base_robot";
    //tf位置数据：x,y,z,方向
    msg_odom_trans.transform.translation.x = position_x.float_type;
    msg_odom_trans.transform.translation.y = position_y.float_type;
    msg_odom_trans.transform.translation.z = 0.0;
    msg_odom_trans.transform.rotation = msg_odom_quat;
    //发布tf坐标变化
    //odom_broadcaster.sendTransform(odom_trans);


    //载入里程计时间戳
    msg_odom.header.stamp = ros::Time::now();
    //里程计的父子坐标系
    msg_odom.header.frame_id = "odom_base";
    msg_odom.child_frame_id = "base_robot";
    //里程计位置数据：x,y,z,方向
    msg_odom.pose.pose.position.x = position_x.float_type;
    msg_odom.pose.pose.position.y = position_y.float_type;
    msg_odom.pose.pose.position.z = 0.0;
    msg_odom.pose.pose.orientation = msg_odom_quat;
    //载入线速度和角速度
    msg_odom.twist.twist.linear.x = vel_linear.float_type;
    msg_odom.twist.twist.linear.y = 0.0;
    msg_odom.twist.twist.angular.z = vel_angular.float_type;
    //载入covariance矩阵
    for(int i = 0; i < 36; i++)
    {
        msg_odom.pose.covariance[i] = covariance[i];
    }
    //发布里程计
    //odom_pub.publish(odom);
}


void Base_Controller::Update_Imu_Topic_Data(void)
{
    //载入坐标（tf）变换时间戳
    msg_imu_trans.header.stamp = ros::Time::now();
    //发布坐标变换的父子坐标系
    msg_imu_trans.header.frame_id = "base_link";
    msg_imu_trans.child_frame_id = "imu_link";
    //tf位置数据：x,y,z,方向
    msg_imu_trans.transform.translation.x = 0.5;
    msg_imu_trans.transform.translation.y = 0.0;
    msg_imu_trans.transform.translation.z = 0.0;
    msg_imu_trans.transform.rotation = tf::createQuaternionMsgFromYaw(0.0);
    //发布tf坐标变化
    //odom_broadcaster.sendTransform(odom_trans);


    msg_imu_data.header.stamp = ros::Time::now();
    msg_imu_data.header.frame_id = "imu_link";
    //四元数位姿
    msg_imu_data.orientation.x = QUAT_1.float_type;
    msg_imu_data.orientation.y = QUAT_2.float_type;
    msg_imu_data.orientation.z = QUAT_3.float_type;
    msg_imu_data.orientation.w = QUAT_0.float_type;
    //载入covariance矩阵
    for(int i = 0; i < 9; i++)
    {b_Is_obstacle_avoidance = false;
        //imu_data.orientation_covariance[i] = imu_data_orientation_covariance[i];
    }
    //线加速度
    msg_imu_data.linear_acceleration.x = ACC_x.float_type;
    msg_imu_data.linear_acceleration.y = ACC_y.float_type;
    msg_imu_data.linear_acceleration.z = ACC_z.float_type;
    //载入covariance矩阵
    for(int i = 0; i < 9; i++)
    {
        //imu_data.linear_acceleration_covariance[i] = imu_data_linear_acceleration_covariance[i];
    }
    //角速度
    msg_imu_data.angular_velocity.x = GY_x.float_type;
    msg_imu_data.angular_velocity.y = GY_y.float_type;
    msg_imu_data.angular_velocity.z = GY_z.float_type;
    //载入covariance矩阵
    for(int i = 0; i < 9; i++)
    {
        //imu_data.angular_velocity_covariance[i] = imu_data_angular_velocity_covariance[i];
    }
    //IMU_pub.publish(imu_data);

}

void Base_Controller::get_robot_pose(void)
{

}

void Base_Controller::ROS_base_control_to_robot(void)
{
    double robot_temp_x_sum=0,robot_temp_y_sum=0,robot_temp_yaw_sum=0;
    double Position_kp=1.0;
    double Position_PID_out_limit=0.5,Angle_PID_out_limit=20;


    robot_temp_x_buf[filter_count] = msg_robot_pose.x;
    robot_temp_y_buf[filter_count] = msg_robot_pose.y;
    robot_temp_yaw_buf[filter_count] = msg_robot_pose.z; // note remap z to yaw here

    if(filter_count++ >= Fliter_size) filter_count=0;
    for(char i=0;i<Fliter_size;i++)
    {
        robot_temp_x_sum += robot_temp_x_buf[i];
        robot_temp_y_sum += robot_temp_y_buf[i];
        robot_temp_yaw_sum += robot_temp_yaw_buf[i];
    }

    float robot_temp_x = robot_temp_x_sum/Fliter_size;
    float robot_temp_y = robot_temp_y_sum/Fliter_size;
    //robot_temp_yaw = robot_temp_yaw_sum/Fliter_size;

    float robot_delta_x = msg_target_pose.x - robot_temp_x;
    float robot_delta_y = msg_target_pose.y - robot_temp_y;
    float robot_delta_yaw =  msg_target_pose.z - msg_robot_pose.z; // note remap z to yaw here

    if(robot_delta_yaw> 180) robot_delta_yaw=robot_delta_yaw-360;
    if(robot_delta_yaw<-180) robot_delta_yaw=robot_delta_yaw+360;

    //if(fabs(robot_delta_yaw)>90) robot_delta_yaw=90;

    float robot_delta_dis = sqrt(pow(robot_delta_x, 2) + pow(robot_delta_y, 2));
    float robot_delta_theta = (atan2(-robot_delta_y,robot_delta_x)*180/3.1416 - msg_robot_pose.z); // note remap z to yaw here
    float robot_vel_x = robot_delta_dis*cos(robot_delta_theta/180*3.1416);
    float robot_vel_y = -robot_delta_dis*sin(robot_delta_theta/180*3.1416);


    msg_target_robot_vel.linear.x  =  0.6*Position_kp * robot_vel_x ;

    msg_target_robot_vel.linear.y = 1.2*Position_kp * robot_vel_y ;
    msg_target_robot_vel.angular.z = -0.9*Position_kp * robot_delta_yaw;



    if(sqrt(pow(robot_delta_x, 2) + pow(robot_delta_y, 2))<0.02)
    {
        msg_target_robot_vel.linear.x = 0;
        msg_target_robot_vel.linear.y = 0;
    }
    if(fabs(robot_delta_yaw)<2)
    {
        msg_target_robot_vel.angular.z = 0;
    }

    if(fabs(robot_delta_yaw)<3 && Changed_target_position_flag==1)
    {
        robot_direction_flag=1;
    }
    if(fabs(robot_delta_yaw)>=3 && robot_direction_flag==0)
    {
        msg_target_robot_vel.linear.x = 0;
        msg_target_robot_vel.linear.y = 0;
    }


    if(sqrt(pow(robot_delta_x, 2) + pow(robot_delta_y, 2))<0.03 && fabs(robot_delta_yaw)<2)
    {
        if(Changed_target_position_flag==1 || Changed_fine_tuning_flag==1)
        {
            Arrive_target_position_count++;
        }
    }

    if(Arrive_target_position_count>3)
    {
        Arrive_target_position_flag=1;
        ROS_INFO("... Arrived_target_position ...  \n");

        //key_board_enable_flag = 0;
        //plan_robot_vel.linear.x =0;
        //plan_robot_vel.angular.z =0;

        // notice_position_flag++;  //目标点间巡航
        // if(notice_position_flag>5) notice_position_flag=1;

        // robot_temp_target_x = robot_target_x_test[notice_position_flag];
        // robot_temp_target_y = robot_target_y_test[notice_position_flag];
        // robot_temp_target_yaw = robot_target_yaw_test[notice_position_flag];

        // Changed_target_position_flag=1;
        // Arrive_target_position_flag=0;
        // Auto_Navigation_flag=1;
    }

    //if(Auto_Navigation_flag!=1 || Changed_target_position_flag!=1 || Changed_fine_tuning_flag!=1)
    if(n_robot_state == 0)  // 0: stop ; 1: controlled by keyboard; 2: controlled by Auto; 3: controlled by planner;
    {
        msg_target_robot_vel.linear.x = 0;
        msg_target_robot_vel.linear.y = 0;
        msg_target_robot_vel.angular.z = 0;
    }

    ////////////////////////////////////////////////////////////////////
    if(n_robot_state == 1) // if keyboard then
    {
        msg_target_robot_vel.linear.x = msg_plan_robot_vel.linear.x;
        msg_target_robot_vel.angular.z = msg_plan_robot_vel.angular.z;
    }

    if(n_robot_state == 2 && b_Is_obstacle_avoidance && b_Is_near_goal == false) // if obstacle avoidance and not reach the goal then ...
    {
        msg_target_robot_vel.linear.x = msg_plan_robot_vel.linear.x;
        msg_target_robot_vel.angular.z = msg_plan_robot_vel.angular.z;
    }


    if(msg_target_robot_vel.linear.x>Position_PID_out_limit) msg_target_robot_vel.linear.x = Position_PID_out_limit;
    if(msg_target_robot_vel.linear.x<-Position_PID_out_limit) msg_target_robot_vel.linear.x = -Position_PID_out_limit;
    if(msg_target_robot_vel.linear.y>Position_PID_out_limit) msg_target_robot_vel.linear.y = Position_PID_out_limit;
    if(msg_target_robot_vel.linear.y<-Position_PID_out_limit) msg_target_robot_vel.linear.y = -Position_PID_out_limit;
    if(msg_target_robot_vel.angular.z>Angle_PID_out_limit) msg_target_robot_vel.angular.z = Angle_PID_out_limit; // max:180/5==36 du/s
    if(msg_target_robot_vel.angular.z<-Angle_PID_out_limit) msg_target_robot_vel.angular.z = -Angle_PID_out_limit;

    //将转换好的小车速度分量为左右轮速度
    //Target_Left_Speed.float_type = linear_temp - 0.5f*angular_temp*D ;
    //Target_Right_Speed.float_type = linear_temp + 0.5f*angular_temp*D ;
    Target_Left_Speed.float_type = msg_target_robot_vel.linear.x ;
    Target_Right_Speed.float_type = -msg_target_robot_vel.linear.y ;
    Target_Position_x.float_type = 0;
    Target_Position_y.float_type = 0;
    Target_Angle.float_type = -msg_target_robot_vel.angular.z /180*3.1416;

    for(int i=0;i<4;i++)    //将左右轮速度存入数组中发送给串口
    {
        Send_to_Robot_data[i+2] = Target_Left_Speed.char_type[i];
        Send_to_Robot_data[i+6] = Target_Right_Speed.char_type[i];
        Send_to_Robot_data[i+10] = Target_Position_x.char_type[i];
        Send_to_Robot_data[i+14] = Target_Position_y.char_type[i];
        Send_to_Robot_data[i+18] = Target_Angle.char_type[i];
    }

    //在写入串口的左右轮速度数据后加入 data head
    Send_to_Robot_data[0]=0x53;
    Send_to_Robot_data[1]=0x49;
    Send_to_Robot_data[22]=0x41;

    //写入数据到串口
    ser.write(Send_to_Robot_data,23);   //发送串口数据
}

void Base_Controller::notice_pub_sub_pulisher(id_data_msgs::ID_Data id_data)
{
    pub_notice.publish(id_data);
}

void Base_Controller::notice_display(id_data_msgs::ID_Data notice_msg,bool set)
{
    if(set)
    {
        printf("REC Notice message,ID: %d,Data: ",notice_msg.id);
        for(char i=0;i<8;i++)
        {
            printf("%d ",notice_msg.data[i]);
            if(i==7) printf("\n");
        }
    }
}

void Base_Controller::notice_msgCallback(const id_data_msgs::ID_Data::ConstPtr &notice_msg)
{
    id_data_msgs::ID_Data notice_message;
    notice_data_clear(&notice_message);

    notice_message.id=notice_msg->id;
    for(char i=0;i<8;i++)notice_message.data[i]=notice_msg->data[i];

    // navigation section .v
    if(notice_message.id==2)
    {
        if(notice_message.data[0]==1)
        {
            if(notice_message.data[1]>0)//msg received flag
            {
                Changed_target_position_flag=1;
                Arrive_target_position_flag=0;
                n_robot_state = 2;// 0: stop ; 1: controlled by keyboard; 2: controlled by Auto; 3: controlled by planner;


                int notice_position_flag = notice_message.data[1];
                ROS_INFO("Received notice move to %d target point ! \n",notice_position_flag);

                msg_target_pose.x = robot_target_x[notice_position_flag];
                msg_target_pose.y = robot_target_y[notice_position_flag];
                msg_target_pose.z  = robot_target_yaw[notice_position_flag]; // remap z to yaw here

                notice_data_clear(&notice_data);
                notice_data.id=2;
                notice_data.data[0]=14;
                notice_pub_sub_pulisher(notice_data);
                ROS_INFO("send response data to notice...");
                notice_display(notice_data,true);
            }
        } //  end if(notice_message.data[0]==1)
        else
        if(notice_message.data[0]==2 || notice_message.data[0]==3 || notice_message.data[0]==4 || notice_message.data[0]==5)
        {
            fine_tuning_flag = notice_message.data[0];
            fine_tuning_distance = 1.0*notice_message.data[1]/100.0;
            if(fine_tuning_distance>0.2) fine_tuning_distance=0.2;

            Changed_fine_tuning_flag = 1;
            Arrive_target_position_flag=0;
            n_robot_state = 2;// 0: stop ; 1: controlled by keyboard; 2: controlled by Auto; 3: controlled by planner;

            if(fine_tuning_flag==2)
            {
                msg_target_pose.x = msg_robot_pose.x + fine_tuning_distance;
                msg_target_pose.y = msg_robot_pose.y;
                msg_target_pose.z = msg_robot_pose.z;  // remap z to yaw
            }
            else
            if(fine_tuning_flag==3)
            {
                msg_target_pose.x = msg_robot_pose.x - fine_tuning_distance;
                msg_target_pose.y = msg_robot_pose.y;
                msg_target_pose.z = msg_robot_pose.z;  // remap z to yaw
            }
            else
            if(fine_tuning_flag==4)
            {
                msg_target_pose.x = msg_robot_pose.x;
                msg_target_pose.y = msg_robot_pose.y + fine_tuning_distance;
                msg_target_pose.z = msg_robot_pose.z;  // remap z to yaw
            }
            else
            if(fine_tuning_flag==5)
            {
                msg_target_pose.x = msg_robot_pose.x;
                msg_target_pose.y = msg_robot_pose.y - fine_tuning_distance;
                msg_target_pose.z = msg_robot_pose.z;  // remap z to yaw
            }

            notice_data_clear(&notice_data);
            notice_data.id=2;
            notice_data.data[0]=16;
            notice_pub_sub_pulisher(notice_data);
            ROS_INFO("send responseresponse data to notice...");
            notice_display(notice_data,true);
        } //  end if(notice_message.data[0]==2)
        else
        {
            // Changed_target_position_flag=0;
            // Arrive_target_position_flag=0;
            // Auto_Navigation_flag=0;
            // notice_position_flag=0;
            ROS_INFO("Received wrong notice data !!! \n");
            notice_display(notice_data,true);
        }
    }
    else
    {
        ROS_INFO("Received wrong ID notice data !!! \n");
    }

}

void Base_Controller::notice_sub_spinner(char set)
{
    if(set==1)
        notice_spinner->start();
    if(set==0)
        notice_spinner->stop();
}
