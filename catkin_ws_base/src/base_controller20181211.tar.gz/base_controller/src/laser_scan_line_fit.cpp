#include <ros/ros.h>
#include "sensor_msgs/LaserScan.h"
#include <math.h>
using namespace std;

float angle_min;
float angle_max;
float angle_increment;
float range_min;
float range_max;
//只取+-30度的数据
float ranges[61];
float position_x;
float position_y;

int table_index=0;
float target_angle_start=-0.26;

sensor_msgs::LaserScan mod_scan_data;

float lineFit(int column);
void laser_scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg );

void laser_scanCallback(const sensor_msgs::LaserScan::ConstPtr& msg )
{

    int angle_num=0;
    vector<float> temp_range;
    angle_min = msg->angle_min;
    angle_max = msg->angle_max;
    angle_increment = msg->angle_increment;

    mod_scan_data = *msg;

    angle_num = 2.0*fabs(target_angle_start) / msg->angle_increment;

    for (int i = 0;i< angle_num-1;i++)
    {
        if (msg->intensities[i+237] > 1)
        {
			ranges[i] = msg->ranges[i+237];
        }
		else 
		{
			ranges[i] = 0;
		}
        ranges[i] = msg->ranges[i+table_index];

        temp_range.push_back(msg->ranges[i + (target_angle_start-angle_min)/msg->angle_increment ]);
        //mod_scan_data.ranges[i] = msg->ranges[i + (target_angle_start-angle_min)/msg->angle_increment ];
    }

    mod_scan_data.ranges = temp_range;
    mod_scan_data.angle_min = target_angle_start;
    mod_scan_data.angle_max = -target_angle_start;


    ROS_INFO("angle_num : %d" , angle_num);
    lineFit(1);
}

float lineFit(int column)
{
    int count = 0;
	int value_count = 0;

    double A = 0.0 ,B = 0.0 ,C = 0.0,D = 0.0,E = 0.0,F = 0.0;
    double a=0, b=0, TEMP = 0; 
    double Line_angle=0,Line_dis=0;
	// ros::Rate loop_rate(30);
	// while(ros::ok())
	// {
	// 	count++;p
	// 	if (count >60)
	// 		break;
	// 	ros::spinOnce();
	// 	loop_rate.sleep();
	// }

    value_count = 0;
    for (int i =0+(column-1)*15;i < 31+(column-1)*15;i++ )
    {	
        if ( ranges[i] > 0.05)
        {
            position_x = ranges[i]*cos(angle_min+angle_increment*(i+table_index) - 0.016);
            position_y = ranges[i]*sin(angle_min+angle_increment*(i+table_index) - 0.016);
            // position_x = ranges[i]*cos(angle_increment*(i+table_index) - 0.016);
            // position_y = ranges[i]*sin(angle_increment*(i+table_index) - 0.016);
            //ROS_INFO("index:%d,data:%3.3f,x:%3.3f,y:%3.3f",i+table_index,ranges[i],position_x,position_y);
            A += position_y * position_y;  
            B += position_y;  
            C += position_y * position_x;  
            D += position_x; 
            value_count++;
        }	
    }
    
    //执行拟合  数据点position_x[value_count]，position_y[value_count] ，数量value_count
    //以position_y为横轴，position_x为纵轴
           
    // 计算斜率a和截距b 
    TEMP = (value_count*A - B*B);

    ROS_INFO("A:%3.3f , B:%3.3f , C:%3.3f , D:%3.3f , TEMP:%3.3f",A,B,C,D,TEMP);

    if( TEMP>-0.000001 &&  TEMP<0.000001)// 判断分母不为0  
    {  
        a = 1;  
        b = 0; 
        ROS_INFO("Line angle : %3.3f , Line_dis : %3.3f " ,a,b);
        //break; 
    }  
    else  
    {  
        a = (value_count*C - B*D) / TEMP;  
        b = (A*D - B*C) / TEMP;
        Line_angle = atan(a)*180/3.1415926 + 0.0;
        Line_dis = sin(atan(a))*b/a;
        ROS_INFO("Line angle : %3.3f , Line_dis : %3.3f " ,Line_angle,Line_dis);
        return Line_angle;
    }

	return 0;	
}



int main(int argc,char **argv)
{
	
	ros::init(argc,argv,"LaserScan_LineFit");
	ros::NodeHandle n;
	

	ros::Subscriber laser_scan_data = n.subscribe("/scan",10,laser_scanCallback);
    ros::Publisher laser_pub = n.advertise<sensor_msgs::LaserScan>("mod_scan", 20);
    
	ros::Rate loop_rate(10);
	int count = 0;
	while(ros::ok())
	{
	    count++;
        //lineFit(1);
        laser_pub.publish(mod_scan_data);
		ros::spinOnce();
		loop_rate.sleep();
	}
}


